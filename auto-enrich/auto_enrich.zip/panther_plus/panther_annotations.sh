#!/bin/bash

# Check if two arguments are given
if [ $# -ne 2 ]; then
	printf "Usage: %s <organism_name> <short_species_name>\n" "$0"
	exit 1
fi

# Assign arguments to variables
name="$1"	#same organism name as referenced in the field "name" in the panther supported_genomes file
short="$2"	#short species name to keep coherence between the input species names

# Download species complete sequence classification file with genes annotations
printf "Downloading PANTHER annotations file...\n"
curl -O "https://data.pantherdb.org/ftp/sequence_classifications/current_release/PANTHER_Sequence_Classification_files/PTHR19.0_${name}"
annotations_file="PTHR19.0_${name}"

# Check if curl was successful and file exists
if [[ $? -eq 0 && -s "$annotations_file" ]]; then
	printf "Download successful: %s\n" "$annotations_file"
else
	printf "Download failed!\n" >&2
	exit 1
fi

# Start file processing variables
simplified_annot="${short}_PTHR19.0_annotations"

awk -F'\t' '
{
	id = $2;
	gene = $3;

	# Join all columns from 7 onwards into one string, separated by ;
	terms = "";
	for (i = 7; i <= NF; i++) {
		terms = terms $i ";";
	}

	# Replace tabs with semicolons (safety)
	gsub(/\t/, ";", terms);

	# Replace every > with ;
	gsub(/>/, ";", terms);

	# Extract all substrings between # and the next ;
	matches = "";
	while (match(terms, /#[^;]+/)) {
		term = substr(terms, RSTART + 1, RLENGTH - 1);  # Skip the '#' character
		matches = matches term ";";
		terms = substr(terms, RSTART + RLENGTH);
	}

	print id "\t" gene "\t" matches;
}' "$annotations_file" > "$simplified_annot"

printf "...processing completed. Processed annotations file saved as %s\n" "$simplified_annot"

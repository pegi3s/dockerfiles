#!/bin/bash

# Check if user provided a file, organism and annotated base ID

if [ $# -ne 2 ]; then
	printf "Usage: %s <ids_map_file> <taxon_id>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_file="$1"
taxon_id="$2"

# Read gene IDs from input, remove empty lines and carriage returns
query_ids=$(awk -F'\t' 'NF && $1 != "" { print $1 }' "$input_file")

# Convert gene IDs into a comma-separated list with "GeneID:" prefix
query_array=$(awk '{for(i=1;i<=NF;i++) printf "GeneID:%s,", $i}' <<< "$query_ids" | sed 's/,$//')

# Send a request post to every annotated datasets in PANTHER
# List of all available datasets
datasets=(
	"GO:0003674"
	"GO:0008150"
	"GO:0005575"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_MF"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_BP"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_CC"
	"ANNOT_TYPE_ID_PANTHER_PC"
	"ANNOT_TYPE_ID_PANTHER_PATHWAY"
	"ANNOT_TYPE_ID_REACTOME_PATHWAY"
)

# Loop through each dataset and make a POST request
for dataset in "${datasets[@]}"; do
	# URL-encode the input database - substitute : for %A
	encod_ds=$(echo "$dataset" | tr -d '\n' |jq -sRr @uri)

	# Build the URl for PANTHER curl post
	url="https://www.pantherdb.org/services/oai/pantherdb/enrich/overrep?geneInputList=${query_array}&organism=${taxon_id}&annotDataSet=${encod_ds}&enrichmentTestType=FISHER&correction=FDR"

	# Send curl post
	output_file="output_${dataset//[:\/_}"
	printf "Requesting from %s...\n" "$dataset"
	curl -X POST $url -H "accept:application/json" -o "$output_file"

	printf "Output saved to %s.\n\n" "$output_file"
done

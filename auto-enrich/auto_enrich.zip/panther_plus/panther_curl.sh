#!/bin/bash

# Usage: ./script.sh <ids_map_file> <taxon_id>

if [ $# -ne 2 ]; then
	printf "Usage: %s <ids_map_file> <taxon_id>\n" "$0"
	exit 1
fi

input_file="$1"
taxon_id="$2"

# Read gene IDs, remove empty lines and format with "GeneID:" prefix
#query_ids=$(awk 'NF { print "GeneID:" $1 }' "$input_file" | paste -sd',' -)		#gene list
query_ids=$(awk -F'\t' 'NF && $1 != "" { print "GeneID:" $1 }' "$input_file" | paste -sd',' -)		#mapped gene list

# List of annotation datasets
datasets=(
	"GO:0003674"
	"GO:0008150"
	"GO:0005575"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_MF"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_BP"
	"ANNOT_TYPE_ID_PANTHER_GO_SLIM_CC"
	"ANNOT_TYPE_ID_PANTHER_PC"
	"ANNOT_TYPE_ID_PANTHER_PATHWAY"
	"ANNOT_TYPE_ID_REACTOME_PATHWAY"
)

# Loop through each dataset
for dataset in "${datasets[@]}"; do
	output_file="output_${dataset//[^a-zA-Z0-9]/_}"

	printf "Requesting enrichment for %s...\n" "$dataset"

	curl -X POST "https://www.pantherdb.org/services/oai/pantherdb/enrich/overrep" \
		-H "accept: application/json" \
		-H "Content-Type: application/x-www-form-urlencoded" \
		--data-urlencode "geneInputList=${query_ids}" \
		--data-urlencode "organism=${taxon_id}" \
		--data-urlencode "annotDataSet=${dataset}" \
		--data-urlencode "enrichmentTestType=FISHER" \
		--data-urlencode "correction=FDR" \
		-o "$output_file"

	printf "Output saved to %s.\n\n" "$output_file"
done

#!/bin/bash

# Check input
if [ $# -ne 1 ]; then
	printf "Usage: %s <terms_annotations_results>\n" "$0"
	exit 1
fi

input_file="$1"
output_file="cumulative_distribution.tsv"

# Check for input files
if [[ ! -f "$input_file" ]]; then
	printf "Error: File '%s' not found." "$input_file"
	exit 1
fi

# 1. Count number of each gene occurence in terms
gene_counts="gene_counts"
# Extract column 6 (zero-indexed column 5), split space-separated values, clean quotes, count, and save
tail -n +2 "$input_file" | \
	cut -d',' -f6 | \
	tr ' ' '\n' | \
	sed "s/'//g" | \
	sed '/^$/d' | \
	sort | \
	uniq -c | \
	awk '{print $2 "\t" $1}' > "$gene_counts"

# 2. Count the distribution of the genes occurences. How many genes appeared N times?
count_distribution="count_distribution"
cut -f2 "$gene_counts" | sort | uniq -c | awk '{print $2 "\t" $1}' > "$count_distribution"

temp_file="distribution.temp"
printf "N_Occurrences\tN_Genes\tProportions\tCumulative_Distribution(CDF)\n" > "$temp_file"
# 3. Get the proportion of occurences in relation to the total number of genes
total_genes=$(awk '{sum+=$1} END {print sum}' "$count_distribution")
sort -n -k1,1 "$count_distribution" | awk -v total="$total_genes" '
BEGIN {
	cum_sum = 0;
}
{
	proportion = ($1 / total)*100;
	cum_sum += proportion;
	printf "%s\t%s\t%.4f\t%.4f\n", $1, $2, proportion, cum_sum;
}' >> "$temp_file"

# Replace the original file with the new file
mv "$temp_file" "$output_file"
#!/bin/bash

# Find all results files
result_files=($(ls results_*))

# Check if there are any
if [ ${#result_files[@]} -eq 0 ]; then
	printf "No results\n"
	exit 0
fi

# Creating header for short and long results files
printf "TermID,Name,P-Value(FDR),Source\n" > short_results.csv
printf "TermID,Name,P-Value,FDR,Fold_Enrichment,Plus_Minus,Source,Number_in_list,Number_in_reference\n" > long_results.csv

# Loop over each result file
for file in "${result_files[@]}"; do
	success=true
	# Skip the header from each file and append selected columns
	# Short results
	awk -F',' 'NR>1 {print $1 "," $2 "," $4 "," $7}' "$file" >> short_results.csv
	if [ $? -ne 0 ]; then
		printf "Error processing short results for %s.\n" "$file"
		success=false
	fi

	# Long results
	awk -F',' 'NR>1 {print $1 "," $2 "," $3 "," $4 "," $5 "," $6 "," $7 "," $8 "," $9}' "$file" >> long_results.csv
	if [ $? -ne 0 ]; then
		printf "Error processing Long result for %s.\n" "$file"
		success=false
	fi
	
	# Check if file processed with success
	if [ "$success" = false ]; then
		printf "Error processing results for %s.\n" "$file"
		exit 1
	fi
done

# Check if four arguments were provided
if [ $# -ne 5 ]; then
	printf "Usage: %s <ids_list_map> <species_name> <panther_annotations> <reac_annotations> <uniprot_map>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_list="$1"
species="$2"
panther_annot="$3"
reac_annot="$4"
uniprot_map="$5"
results_file="long_results.csv"

output_dir="terms_annotations"
mkdir -p "$output_dir"

go_cache_file="go_annotations_cache"

# Function to download GO annotations and extract gene symbols
get_go_terms_annotations() {
	local GO_TERM="$1"
	local TAXON_LABEL="$2"
	local TERM_DIR="$3"

	local GO_TERM_ENC="${GO_TERM/:/%3A}"
	local TAXON_LABEL_ENC="${TAXON_LABEL// /%20}"
	local output_file="${TERM_DIR}/annotations_${GO_TERM//:/_}_${TAXON_LABEL// /_}.csv"
	local genes_file="${TERM_DIR}/genes_in_term"

	# Check cache first
	if genes_line=$(grep -P "^${GO_TERM}\t" "$go_cache_file" 2>/dev/null); then
		genes_line=$(echo "$genes_line" | cut -f2-)
		echo "$genes_line" | tr ' ' '\n' | sort -u > "$genes_file"
		return
	fi

	# Not cached, download
	# printf "Downloading GO annotations for %s (%s)\n" "$GO_TERM" "$TAXON_LABEL"
	curl -s "https://golr-aux.geneontology.io/solr/select?defType=edismax&qt=standard&indent=on&wt=csv&rows=100000&start=0&fl=bioentity_label&facet=false&fq=document_category:%22annotation%22&fq=isa_partof_closure:%22$GO_TERM_ENC%22&fq=taxon_subset_closure_label:%22$TAXON_LABEL_ENC%22&q=*%3A*" -o "$output_file"

	awk -F'\t' 'NR > 1 && $1 != "" && !seen[$1]++ { print $1 }' "$output_file" > "$genes_file"

	# Save to cache: join genes by space
	genes_joined=$(paste -sd' ' "$genes_file")
	echo -e "${GO_TERM}\t${genes_joined}" >> "$go_cache_file"
}

combined_results="terms_annotations_results.csv"
printf "TermID,Name,Source,Plus_Minus,Fold_Enrichment,Ratio(%%),ListCount,Genes_in_list,TermCount,Genes_in_term\n" > "$combined_results"

declare -A map_uniprot map_symbol

# Load uniprot_map file into associative arrays
while IFS=$'\t' read -r uniprot symbol name organism; do
	[[ -n "$uniprot" && -n "$symbol" ]] && map_uniprot["$uniprot"]="$symbol"
done < "$uniprot_map"

total_terms=$(($(wc -l < "$results_file") - 1))
term_index=0

{
	read #skip header
	while IFS=',' read -r term name _3 _4 fold plus_minus source _8 _9; do
		sanitized_name=$(printf "%s" "$name" | sed 's/[^a-zA-Z0-9_]/_/g')
		# Default term_dir
		term_dir="${output_dir}/${term}_${sanitized_name}"

		((term_index++))
		echo "Processing enriched term annotations $term_index/$total_terms: $term ($name)"

		# Adjust directory name for PANTHER if needed
		if [[ "$source" == *PANTHER* ]]; then
			term_dir="${output_dir}/PTR_${term}_${sanitized_name}"
		fi

		# Create the directory once, regardless of source
		mkdir -p "$term_dir"
		genes_in_term="$term_dir/genes_in_term"
		genes_in_list="$term_dir/genes_in_list"

		if [[ "$source" == *PANTHER* ]]; then
			# Directly get UniProt IDs for the term and save genes_in_term
			awk -F'\t' -v term="$term" '$3 ~ "(^|;)" term "(;|$)" {print $1}' "$panther_annot" 2>/dev/null | sort -u > "$genes_in_term"
			if [[ ! -s "$genes_in_term" ]]; then
				printf "\nNo annotations found for term '%s' in PANTHER annotations file.\n" "$name"
				continue
			fi
		elif [[ "$source" == REACTOME_PATHWAY ]]; then
			# Directly get UniProt IDs for the term and save genes_in_term
			awk -F'\t' -v term="$term" '
			$1 == term {
				n = split($3, ids, ",")
				for (i = 1; i <= n; i++) {
					print ids[i]
				}
			}' "$reac_annot" | sort -u > "$genes_in_term"
			if [[ ! -s "$genes_in_term" ]]; then
				printf "No annotations found for term '%s' in REACTOME annotations file.\n" "$name"
				continue
			fi
		elif [[ "$source" == GO_* && "$source" != *PANTHER* ]]; then
			get_go_terms_annotations "$term" "$species" "$term_dir"		#symbols
		else
			continue
		fi

		# Now do the matched gene filtering part in the same loop:
		matched_genes=""

		printf "GeneID\tUniProtID\tGeneSymbol\tOfficialFullName\n" > "$genes_in_list"
		awk -F'\t' '
			NR==FNR { term[$1]; next }         # Load UniProt OR symbol (file will contain one type)
			($2 in term || $3 in term) { print $0 }
		' "$genes_in_term" "$input_list" > "$genes_in_list"

		if [[ ! -s "$genes_in_list" ]]; then
			printf "No input genes associated with enriched term '%s'.\n" "$name"
		fi

		symbol_output="$term_dir/genes_in_term_symbols"
		unmapped_output="$term_dir/uniprots_not_mapped_to_symbols"

		if [[ "$source" == *PANTHER* || "$source" == REACTOME_PATHWAY ]]; then
			while read -r gene; do
				if [[ -n "${map_uniprot[$gene]}" ]]; then
					echo "${map_uniprot[$gene]}" >> "$symbol_output"
				else
					echo "$gene" >> "$unmapped_output"
				fi
			done < "$genes_in_term"
			mv "$genes_in_term" "$term_dir/genes_in_term_uniprots"
		else
			mv "$genes_in_term" "$symbol_output"
		fi

		if [[ ! -f "$symbol_output" ]]; then
			echo "Skipping term '$term' — not found."
			continue
		fi
		
		term_count=$(awk 'END{print NR}' "$term_dir/genes_in_term_symbols")
		matched_count=$(( $(awk 'END{print NR}' "$genes_in_list") - 1 ))
		matched_genes=$(awk -F'\t' 'NR>1 { printf "%s ", $3 }' "$genes_in_list")
		ratio=$(awk -v m="$matched_count" -v t="$term_count" 'BEGIN { if (t > 0) printf "%.2f", (m / t)*100; else print 0 }')

		term_annotations=$(paste -sd' ' "$term_dir/genes_in_term_symbols")
		printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" \
			"$term" "$sanitized_name" "$source" "$plus_minus" "$fold" "$ratio" "$matched_count" "${matched_genes% }" "$term_count" "$term_annotations" >> "$combined_results"
	done
} < "$results_file"
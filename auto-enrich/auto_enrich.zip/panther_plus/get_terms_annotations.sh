# Check if four arguments were provided
if [ $# -ne 4 ]; then
	printf "Usage: %s <genes_ids_map> <species_name> <simple_panther_annotations> <reac_annotations>\n" "$0"
	exit 1
fi

# Assign arguments to variables
map_file="$1"
species="$2"
panther_annot="$3"
reac_annot="$4"
results_file="short_results.csv"

output_dir="terms_annotations"
mkdir -p "$output_dir"

get_go_terms_annotations() {
	local GO_TERM="$1"
	local TAXON_LABEL="$2"
	local TERM_DIR="$3"

	local GO_TERM_ENC="${GO_TERM/:/%3A}"
	local TAXON_LABEL_ENC="${TAXON_LABEL// /%20}"

	# TERM_DIR is pre-created outside, no need to mkdir here

	local URL="https://golr-aux.geneontology.io/solr/select?defType=edismax&qt=standard&indent=on&wt=csv&rows=100000&start=0&fl=source%2Cbioentity_internal_id%2Cbioentity_label%2Cqualifier%2Cannotation_class%2Creference%2Cevidence_type%2Cevidence_with%2Caspect%2Cbioentity_name%2Csynonym%2Ctype%2Ctaxon%2Cdate%2Cassigned_by%2Cannotation_extension_class%2Cbioentity_isoform&facet=true&facet.mincount=1&facet.sort=count&json.nl=arrarr&facet.limit=25&csv.encapsulator=&csv.separator=%09&csv.header=true&csv.mv.separator=%7C&fq=document_category:%22annotation%22&fq=isa_partof_closure:%22$GO_TERM_ENC%22&fq=taxon_subset_closure_label:%22$TAXON_LABEL_ENC%22&q=*%3A*"
	local PAGE_URL="https://amigo.geneontology.org/amigo/term/${GO_TERM}"
	printf "Downloading annotations for GO term: %s, Taxon: %s (%s)\n" "$GO_TERM" "$TAXON_LABEL" "$PAGE_URL"
	output_file="${TERM_DIR}/annotations_${GO_TERM//:/_}_${TAXON_LABEL// /_}.csv"
	curl -s "$URL" -o "$output_file"

	if [[ ! -s "$output_file" ]]; then
		printf "⚠ No data retrieved or empty file: %s\n" "$output_file"
		return 0
	fi

	#Extract gene identifiers from 2nd column and save to genes_in_term inside TERM_DIR
	awk -F'\t' 'NR > 1 { print $2 }' "$output_file" | sort -u > "${TERM_DIR}/genes_in_term"
	printf "Genes saved to: %s\n" "${TERM_DIR}/genes_in_term"

	rm "$output_file"
}

combined_results="terms_annotations_results.csv"
printf "TermID,Name,Source,Ratio(%%),ListCount,GeneIDs_in_list,Genes_in_list,TermCount,Genes_in_term\n" > "$combined_results"

tail -n +2 "$results_file" | while IFS=',' read -r term name col3 source; do
	sanitized_name=$(printf "%s" "$name" | sed 's/[^a-zA-Z0-9_]/_/g')
	# Default term_dir
	term_dir="${output_dir}/${term}_${sanitized_name}"

	# Adjust directory name for PANTHER if needed
	if [[ "$source" == *PANTHER* ]]; then
		term_dir="${output_dir}/PTR_${term}_${sanitized_name}"
	fi

	# Create the directory once, regardless of source
	mkdir -p "$term_dir"

	if [[ "$source" == *PANTHER* ]]; then
		# Directly get UniProt IDs for the term and save genes_in_term
		awk -F'\t' -v term="$term" '$2 ~ "(^|;)" term "(;|$)" {print $1}' "$panther_annot" | sort -u > "$term_dir/genes_in_term"

	elif [[ "$source" == GO_* && "$source" != *PANTHER* ]]; then
		printf "\nGetting terms annotations for %s %s\n" "$term" "$source"
		get_go_terms_annotations "$term" "$species" "$term_dir"

	elif [[ "$source" == REACTOME_PATHWAY ]]; then
		printf "\nGetting terms annotations for %s %s\n" "$term" "$source"
		awk -F'\t' -v term="REAC:$term" '$1 == term { for (i=3; i<=NF; i++) print $i }' "$reac_annot" | sort -u > "$term_dir/genes_in_term"

	else
		continue
	fi

	# Now do the matched gene filtering part in the same loop:
	printf "\nGetting genes in list %s\n" "$term"
	matched_ids=""
	matched_genes=""

	if [[ "$species" == "Mus musculus" ]]; then
		printf "GeneID\tUniProtID\tGeneSymbol\tOfficialFullName\tMGI\n" > "$term_dir/genes_in_list"
		while IFS=$'\t' read -r gene_id uniprot_id gene_symbol full_name mgi; do
			match_found=""

			if [[ "$source" == GO_* ]]; then
				if [[ -n "$mgi" ]] && grep -iwq "$mgi" "$term_dir/genes_in_term"; then
					match_found=1
				fi
			else
				if grep -iwq "$uniprot_id" "$term_dir/genes_in_term" || grep -iwq "$gene_symbol" "$term_dir/genes_in_term"; then
					match_found=1
				fi
			fi

			if [[ -n "$match_found" ]]; then
				printf "Match found: GeneID %s with Gene Symbol %s, UniProtID %s, MGI %s\n" "$gene_id" "$gene_symbol" "$uniprot_id" "$mgi"
				printf "%s\t%s\t%s\t%s\t%s\n" "$gene_id" "$uniprot_id" "$gene_symbol" "$full_name" "$mgi">> "$term_dir/genes_in_list"
				matched_ids+="'$gene_id' "
				matched_genes+="'$gene_symbol' "
			fi
		done < "$map_file"

	else
		printf "GeneID\tUniProtID\tGeneSymbol\tOfficialFullName\n" > "$term_dir/genes_in_list"
		while IFS=$'\t' read -r gene_id uniprot_id gene_symbol full_name; do
			if grep -iwq "$uniprot_id" "$term_dir/genes_in_term" || grep -iwq "$gene_symbol" "$term_dir/genes_in_term"; then
				printf "Match found: GeneID %s with Gene Symbol %s and UniProtID %s\n" "$gene_id" "$gene_symbol" "$uniprot_id"
				printf "%s\t%s\t%s\t%s\n" "$gene_id" "$uniprot_id" "$gene_symbol" "$full_name" >> "$term_dir/genes_in_list"
				matched_ids+="'$gene_id' "
				matched_genes+="'$gene_symbol' "
			fi
		done < "$map_file"
	fi

	genes_count=$(wc -l < "$term_dir/genes_in_term")
	matched_count=$(($(wc -l < "$term_dir/genes_in_list") - 1))
	ratio=$(awk -v m="$matched_count" -v t="$genes_count" 'BEGIN { if (t > 0) printf "%.2f", (m / t)*100; else print 0 }')

	term_annotations=$(paste -sd' ' "$term_dir/genes_in_term")
	printf "%s,%s,%s,%s,%s,%s,%s,%s,%s\n" \
		"$term" "$sanitized_name" "$source" "$ratio" "$matched_count" "${matched_ids% }" "${matched_genes% }" "$genes_count" "$term_annotations" >> "$combined_results"
done

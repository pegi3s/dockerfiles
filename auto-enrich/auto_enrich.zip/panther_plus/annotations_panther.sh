#!/bin/bash

# Check if two arguments are given
if [ $# -ne 2 ]; then
	printf "Usage: %s <organism_name> <short_species_name>\n" "$0"
	exit 1
fi

# Assign arguments to variables
name="$1"	#same organism name as referenced in the field "name" in the panther supported_genomes file
short="$2"	#short species name to keep coherence between the input species names

# Download species complete sequence classification file with genes annotations
printf "Downloading PANTHER annotations file...\n"
curl -O "https://data.pantherdb.org/ftp/sequence_classifications/current_release/PANTHER_Sequence_Classification_files/PTHR19.0_${name}"
annotations_file="PTHR19.0_${name}"

# Check if curl was successful and file exists
if [[ $? -eq 0 && -s "$annotations_file" ]]; then
	printf "Download successful: %s\n" "$annotations_file"
else
	printf "Download failed!\n" >&2
	exit 1
fi

# Start file processing variables
reduced_annot="reduced_annotations"
simplified_annot="${short}_PTHR19.0_annotations"

# Cut unecessary columns to reduce file size
cut --complement -f1,3-6 "$annotations_file" > "$reduced_annot"
# Replace all tabs and spaces with ;, and remove unwanted punctuation except # and ;
tmp_file=$(mktemp)
tr '\t ' ';' < "$reduced_annot" |
sed 's/[^[:alnum:]#:;]/;/g' |
sed 's/;/\t/' > "$tmp_file"

mv "$tmp_file" "$reduced_annot"

printf "Processing %s...\n" "$annotations_file"

>"$simplified_annot"
# Process the reduced annotations file line by line and extract term name info only
while IFS=$'\t' read -r uniprot_id rest; do
	# Initialize an empty string to store extracted terms
	extracted_terms=""

	# Split the terms by semicolon in the 'rest' part (which is now description and terms)
	IFS=';' read -ra terms <<< "$rest"
	for term in "${terms[@]}"; do
		# Extract everything between # and ;
		if [[ "$term" =~ \#([^;]+) ]]; then
			extracted_terms+="${BASH_REMATCH[1]};"
		fi
	done

	# If extracted terms are found, write to the output file
	if [[ -n "$extracted_terms" ]]; then
		printf "%s\t%s\n" "$uniprot_id" "$extracted_terms" >> "$simplified_annot"
	fi
done < "$reduced_annot"

printf "...processing completed. Processed annotations file saved as %s\n" "$simplified_annot"

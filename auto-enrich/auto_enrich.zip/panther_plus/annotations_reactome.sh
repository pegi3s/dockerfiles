#!/bin/bash

# Verify number of arguments
if [ $# -ne 1 ]; then
	printf "Usage: %s <species>\n" "$0"
	exit 1
fi

# Assign variables
species="$1"

# Check if the input species name contains an underscore, indicating the long form and reduce to short form
if [[ "$species" == *"_"* ]]; then
	# Convert full species name to short form
	species_short="${species:0:1}${species#*_}"
else
	species_short="$1"
fi

# Define file,build the base URL and download URL
zip_file="datasets_${species_short}.name.zip"
url="https://biit.cs.ut.ee/gprofiler//static/gprofiler_${species_short}.name.zip"
wget -O "$zip_file" "$url"

# Check if download was successful
if [ $? -ne 0 ]; then
	printf "Error: downloading the file\n"
	exit 1
fi

# Create temporary directory for extraction
temp_dir=$(mktemp -d)

# Unzip the file into temporary file
unzip "$zip_file" -d "$temp_dir"

# Clear previous merged file if exists
reac_file="${species}_REAC_annotations"
>"$reac_file"

# Search for matching files and merge them
find "$temp_dir" -type f \( -name "*REAC*" \) -exec cat {} + >> "$reac_file"

# Print status
if [[ -s "$reac_file" ]]; then
	printf "Reactome annotations file created: %s\n" "$reac_file"
else
	printf "No matching files found.\n"
fi

# Cleanup: Remove the temporary directory
rm -r "$temp_dir"
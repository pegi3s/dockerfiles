#!/bin/bash

# Check for one given argument
if [[ $# -ne 1 ]]; then
	printf "Usage: %s <panther_output_file>\n" "$0"
	exit 1
fi

# Assign argument
input_file="$1"

# Check if the given file exists
if [ ! -f "$input_file" ]; then
	printf "Error: input file not found.\n"
	exit 1
fi

# Extract the dataset type/source from the input filename
# Remove output_ from the file name from source name
source="${input_file#output_}"

# Remove ANNOT_TYPE_ID_ if present from source name
source="${source#ANNOT_TYPE_ID_}"

case "$source" in
	"GO:0003674") source="GO_MF" ;;
	"GO:0008150") source="GO_BP" ;;
	"GO:0005575") source="GO_CC" ;;
esac

# Define output CSV results file names
output_file="results_${source}.csv"

# Write a header line to output file
printf "TermID,Name,P-Value,FDR,Fold_Enrichment,Plus_Minus,Source,Number_in_list,Number_in_reference\n" > "$output_file"

# Extract data and use jq to filter results with fdr < 0.05
jq -r --arg source "$source" \
	'.results.result[] | select(.fdr < 0.05) | "\(.term.id),\(.term.label | gsub("[^A-Za-z0-9]"; "_")),\(.pValue),\(.fdr),\(.fold_enrichment),\(.plus_minus),\($source),\(.number_in_list),\(.number_in_reference)"' \
	"$input_file" >> "$output_file"

# Check if jq command was successful
if [ $? -ne 0 ]; then
	printf "Error: Processing results failed.\n"
	exit 1
fi

#!/bin/bash

# Verify number of arguments
if [ $# -ne 1 ]; then
	printf "Usage: $0 <species>\n"
	exit 1
fi

# Assign variables
species="$1"

# Check if the input species name contains an underscore, indicating the long form and reduce to short form
if [[ "$species" == *"_"* ]]; then
	# Convert full species name to short form
	species_short="${species:0:1}${species#*_}"
else
	species_short="$1"
fi

# Build the base URL and download URL
url="https://biit.cs.ut.ee/gprofiler//static/gprofiler_full_${species_short}.name.gmt"
wget -O "${species}_gProfiler_annotations.gmt" "$url"

# Check if download was successful
if [ $? -ne 0 ]; then
	printf "Error: downloading the gProfiler Gene Sets file.\n"
	exit 1
fi

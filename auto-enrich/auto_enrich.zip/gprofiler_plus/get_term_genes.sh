#!/bin/bash

# Check if two arguments were provided
if [ $# -lt 2 ]; then
	printf "Usage: %s <input_ids_map_file> <gprofiler_annotations_file>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_file="$1" # Input file containing gene ids in col1, uniprotkbs in col2, gene symbols in col3 and names in col4
gmt_file="$2"

# Assign GO terms file
results_file="short_results.csv"

# Check if the GAF download and unzip was successfull
if [ ! -f "$gmt_file" ]; then
	printf "Error: GMT file not found.\n"
	exit 1
fi

# Create an ouput directory for gene IDs found for each GO:Term in gprofiler results
output_dir="terms_annotations"
mkdir -p "$output_dir"

# Create a combined results file with TermID,Name,Matched_input,GeneNames (from ontology family)
combined_results="terms_annotations_results.csv"
printf "TermID,Name,Source,Ratio(%%),ListCount,GeneIDs_in_list,Genes_in_list,TermCount,Genes_in_term\n" > "$combined_results"

# Loop through each GO term in the Gprofiler short results file
while IFS=',' read -r term_id name col3 source; do
	# Extract all information in the GMT file associated with the given GO term
	matched_lines=$(grep -P "\b$term_id\b" "$gmt_file" | sort | uniq)

	if [ -n "$matched_lines" ]; then
		printf "\nSearching input IDs in TermID %s (%s)\n" "$term_id" "$name"

		# Create a subdirectory for each GO term only if there are matched lines
		sanitized_name=$(printf "%s" "$name" | sed 's/[^a-zA-Z0-9_]/_/g')	# Sanitize name to only number and letters
		term_dir="${output_dir}/${term_id}_${sanitized_name}"
		mkdir -p "$term_dir"

		# Save gene names line by line to genes_in_term
		printf "%s\n" "$matched_lines" | cut -f3- | tr '\t' '\n' > "${term_dir}/genes_in_term"

		# Prepare term_genes as a single string for the combined results
		term_genes=$(printf "%s\n" "$matched_lines" | cut -f3- | tr '\t' ' ' | tr '\n' ' ' | sed 's/ $//')

		# Check if results were found
		if [ -n "$term_genes" ]; then
			# Count total genes in term_genes file
			gene_count=$(wc -l < "${term_dir}/genes_in_term")

			# Initialize an empty variable to accumulate matched ids
			matched_id=""
			matched_symbol=""

			matched_input="genes_in_list"
			# Clear the match file at the start (overwrite if exists)
			printf "GeneID\tUniProtID\tGeneSymbol\tOfficialFullName\n" > "${term_dir}/${matched_input}"
			
			# Now check if any of the input Gene Names are in this GO term's Family
			while IFS=$'\t' read -r gene_id uniprot gene_symbol full_name; do
				# Perfom the matching based on the appropriate ID
				if grep -w "$gene_symbol" "${term_dir}/genes_in_term" > /dev/null; then
					# Compose the line with printf
					line=$(printf "%s\t%s\t%s\t%s\n" "$gene_id" "$uniprot" "$gene_symbol" "$full_name")
					# Remove trailing tab(s) and newline
					clean_line=$(printf "%s" "$line" | sed 's/\t*$//')
					# Add newline and write to file
					printf "%s\n" "$clean_line" >> "${term_dir}/${matched_input}"
					printf "Match found: GeneID %s with Gene Symbol %s\n" "$gene_id" "$gene_symbol"
					# Concatenate gene IDs and names with space separation
					matched_id+="'$gene_id "
					matched_symbol+="'$gene_symbol "
				fi
			done < "$input_file"

			if [ -f "${term_dir}/${matched_input}" ]; then
				# Count matched uniprotIDs
				matched_count=$(wc -l < "${term_dir}/${matched_input}")
				# Exclude header
				matched_count=$((matched_count - 1))
				# Remove the trailing character from matched_input if it exists
				matched_id="${matched_id% }"
				matched_symbol="${matched_symbol% }"
				# Calculate ratio safely (float)
				#ratio=$(awk -v m="$matched_count" -v t="$gene_count" 'BEGIN { if (t > 0) printf "%.4f", m / t; else print 0 }')
				
				# Calculate ratio safely (percentagem)
				ratio=$(awk -v m="$matched_count" -v t="$gene_count" 'BEGIN {
					if (t > 0) printf "%.2f", (m / t) * 100;
					else print "0.00"
				}')
				
			else
				matched_count=0
				matched_id=""
				matched_symbol=""
			fi
			# Append the results to the combined results file
			printf "%s,%s,%s,%s,%s,%s,%s,%s,%s\n" \
				"$term_id" "$sanitized_name" "$source" "$ratio" "$matched_count" "$matched_id" "$matched_symbol" "$gene_count" "$term_genes" >> "$combined_results"
		fi
	fi
done < "$results_file"

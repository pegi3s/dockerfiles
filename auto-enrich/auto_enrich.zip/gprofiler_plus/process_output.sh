#!/bin/bash

# Check if one argument was given
if [ $# -ne 1 ]; then
	printf "Usage: %s <gprofiler_raw_output>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_file="$1"

# Check if input file exists
if [ ! -f "$input_file" ]; then
	printf "Error: input file not found.\n"
	exit 1
fi

# Write header lines to output files
printf "TermID,Name,P-Value,Source\n" > short_results.csv
printf "TermID,Name,Description,P-Value,Precision,Recall,Term_Size,Source,Effective_domain_size,Parents,Group_ID\n" > long_results.csv

# Short results with strictly sanitized .name
jq -r '.result[] | "\(.native),\(.name | gsub("[^A-Za-z0-9]"; "_")),\(.p_value),\(.source)"' "$input_file" >> short_results.csv
# Long results with strictly sanitized .name and .description
jq -r '.result[] | "\(.native),\(.name | gsub("[^A-Za-z0-9]"; "_")),\(.description | gsub("[^A-Za-z0-9]"; "_")),\(.p_value),\(.precision),\(.recall),\(.term_size),\(.source),\(.effective_domain_size),\(.parents | "[" + (map(gsub("[^A-Za-z0-9]"; "_")) | join("_")) + "]"),\(.group_id)"' "$input_file" >> long_results.csv

# Check if jq ran successfully and output files have more than one line
if [ $? -eq 0 ] && [ "$(wc -l < short_results.csv)" -gt 1 ] && [ "$(wc -l < long_results.csv)" -gt 1 ]; then
	printf "\nProcessing successful. Output saved to short_results.csv and long_results.csv in the results directory\n\n"
else
	printf "Error: Processing results failed.\n"
	exit 1
fi
#!/bin/bash

# Check if user provided a file and species

if [ $# -ne 2 ]; then
	printf "Usage: %s <ids_map_file> <species>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_file="$1"
species="$2"

# Read the gene IDs from input file (second argument) and remove empty lines (NF)
query_ids=$(awk -F'\t' 'NF && $1 != "" { print $1 }' "$input_file")

# Convert gene IDs into a comma-separated list formmatted in JSON
query_array=$(printf "%s\n" "$query_ids" | awk '{printf "\"%s\",", $0}' | sed 's/,$//')

# Define JSON payload
json_data="{\"organism\": \"$species\", \"query\":[$query_array], \"significance_threshold_method\": \"fdr\", \"user_threshold\": \"0.05\"}"

# Send curl request
curl -X 'POST' -d "$json_data" 'https://biit.cs.ut.ee/gprofiler/api/gost/profile/' > raw_output

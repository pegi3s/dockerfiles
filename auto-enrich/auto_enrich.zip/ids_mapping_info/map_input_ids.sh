#!/bin/bash

# Check if number of necessary arguments is correct
if [ "$#" -ne 3 ]; then
	printf "Usage: %s <input_ids_file> <mapping_file> <output_file>\n" "$0"
	exit 1
fi

# Assign variables
input_file="$1"
map_file="$2"

if [ ! -f "$input_file" ]; then
	printf "Error: Gene IDs file '%s' not found\n" "$input_file"
	exit 1
fi

# Check if the mapping file exists
if [ ! -f "$map_file" ]; then
	printf "Error: Mapping file '%s' not found.\n" "$map_file"
	exit 1
fi

# Output file of mapped input ids
output_file="$3"
> "$output_file"

# Loop through each gene ID in the input file
while IFS= read -r gene_id; do
	grep -P "^${gene_id}\t" "$map_file" >> "$output_file"
done < "$input_file"
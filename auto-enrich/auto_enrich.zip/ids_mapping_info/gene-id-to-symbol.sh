#!/bin/bash

# Check if user provided a file and organism
if [ $# -ne 1 ]; then
	printf "Usage: %s <gene_ids_list_file>\n" "$0"
	exit 1
fi

# Assign arguments to variables
input_file="$1"
output_file="gene_symbols"

# Read gene IDs into an array, skipping empty lines
mapfile -t gene_array < <(awk 'NF' "$input_file")

# Write header to output TSV file
printf "GeneID\tOfficialSymbol\tFullName\n" > "$output_file"

# Loop through each gene ID
for GENE_ID in "${gene_array[@]}"; do
	URL="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gene&id=${GENE_ID}&retmode=json"

	# Fetch JSON using curl
	RESPONSE=$(curl -s "$URL")

	# Use jq to extract values
	OFFICIAL_SYMBOL=$(echo "$RESPONSE" | jq -r ".result[\"$GENE_ID\"].name")
	OFFICIAL_NAME=$(echo "$RESPONSE" | jq -r ".result[\"$GENE_ID\"].description")

	# Print to terminal (optional)
	printf "\nGene ID: %s\n" "$GENE_ID"
	printf "Official Symbol: %s\n" "$OFFICIAL_SYMBOL"
	printf "Official Full Name: %s\n" "$OFFICIAL_NAME"

	# Append to TSV file
	printf "%s\t%s\t%s\n" "$GENE_ID" "$OFFICIAL_SYMBOL" "$OFFICIAL_NAME" >> "$output_file"
done
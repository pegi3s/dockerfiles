#!/bin/bash
if [ $# -ne 1 ]; then
	printf "Usage: %s <gene_ids_list>\n" "$0"
	exit 1
fi

input_file="$1"
output_file="gene_mgi"

# Write header
printf "NCBI_GeneID\tMGI_ID\n" > "$output_file"

# Process each Entrez ID
while IFS= read -r gene_id; do
	url="https://mygene.info/v3/gene/${gene_id}?fields=MGI"
	printf "Querying GeneID %s MGI (%s)\n" "$gene_id" "$url"
	# Query MyGene.info API
	response=$(curl -s "$url")
	# Parse fields using jq
	mgi_id=$(echo "$response" | jq -r '.MGI // "NA"')
	printf "MGI acquired: %s\n" "$mgi_id"
	#symbol=$(echo "$response" | jq -r '.symbol // "NA"')

	# Write to output with printf
	printf "%s\t%s\n" "$gene_id" "$mgi_id" >> "$output_file"
done < "$input_file"

printf "Done. GeneID to MGI saved to %s\n" "$output_file"
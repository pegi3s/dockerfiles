#!/bin/bash

# Check if two arguments were given
if [ "$#" -ne 2 ]; then
	printf "Usage: %s <input_ids_file> <mapping_file>\n" "$0"
	exit 1
fi

# Assign variables
input_file="$1"
map_file="$2"

# Output file to store IDs not found (to query)
output_file="unmapped_ids"

# Make sure the input file exists
if [ ! -f "$input_file" ]; then
	printf "Error: Input file '%s' not found.\n" "$input_file"
	exit 1
fi

# Create or empty IDs to be queried file (output_file)
> "$output_file"

#  Loop through each gene ID in the input file
while IFS= read -r gene_id; do
	# Check if the gene ID exists in the queried IDs file
	if grep -P "^$gene_id\t" "$map_file" > /dev/null; then
		printf "Gene ID %s mapping found.\n" "$gene_id"
	else
		# If gene ID not found, echo it to the output file
		printf "Gene ID %s not mapped.\n" "$gene_id"
		printf "%s\n" "$gene_id" >> "$output_file"
	fi
done < "$input_file"

# Check if unmapped ids file is empty or not
if [ -s "$output_file" ]; then
	printf "Check complete. Mapping necessary Gene IDs:\n"
else
	printf "Check complete. All input IDs already mapped.\n"
fi
#!/bin/bash

# Check if config file and input file are given
if [ $# -ne 1 ]; then
	printf "Usage: %s <config>\n" "$0"
	exit 1
fi

# Load config and input
source "$1"
output_file="selected_genes_list"
# Only proceed if 'select' variable is defined and not empty
if [ -n "${select:-}" ]; then
	# Convert to zero-based index
	select_col=$((select - 1))
	# Extract gene column index
	gene_col=${gene}
	gene_col=$((gene_col - 1))

	# Read lines and extract genes marked as selected (1)
	tail -n +2 "/data/$input" | while IFS=$'\t' read -r -a columns; do
		if [ "${columns[$select_col]}" = "1" ]; then
			printf "%s\n" "${columns[$gene_col]}" >> "$output_file"
		fi
	done
fi
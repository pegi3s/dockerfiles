#!/bin/bash

# Check input
if [ $# -ne 1 ]; then
	printf "Usage: %s <config_file>\n" "$0"
	exit 1
fi

config="$1"
output="column_header_mapping.txt"

# Load config variables
source "$config"

# Read and split TSV header into array
IFS=$'\t' read -r -a headers < "/data/$input"

# Helper: Convert 1-based index to header name
get_header() {
	local index=$1
	printf "%s" "${headers[$((index - 1))]}"
}

# Write header
printf "Mapping of Config Variables to Header Names\n\n" > "$output"

# Gene
if [[ -n "$gene" ]]; then
	printf "Gene (column %s): %s\n" "$gene" "$(get_header "$gene")" >> "$output"
fi

# Process all avgX variables
for var in "${!avg@}"; do
	val="${!var}"
	if [[ -n "$val" ]]; then
		# Check if single index or multiple
		if [[ "$val" =~ ^[0-9]+$ ]]; then
			# Single index
			printf "%s (column %s): %s\n" "$var" "$val" "$(get_header "$val")" >> "$output"
		else
			# Multiple indices
			IFS=',' read -r -a idxs <<< "$val"
			names=()
			for idx in "${idxs[@]}"; do
				[[ -z "$idx" ]] && continue
				names+=("$(get_header "$idx")")
			done
			IFS=','; printf "%s (columns %s): %s\n" "$var" "$val" "${names[*]}" >> "$output"; IFS=$' \t\n'
		fi
	fi
done

# Print conditions if any
for var in "${!cond@}"; do
	val="${!var}"
	if [[ -n "$val" ]]; then
		printf "%s: %s\n" "$var" "$val" >> "$output"
	fi
done

# Print threshold info
printf "Minimum expression threshold: %s\n" "${expression_min:-Not set}" >> "$output"
printf "Maximum expression threshold: %s\n" "${expression_max:-Not set}" >> "$output"
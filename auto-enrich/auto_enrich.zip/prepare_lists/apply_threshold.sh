#!/bin/bash

# Check if the config file and processed averages file are given
if [ $# -ne 2 ]; then
	printf "Usage: %s <config> <conditions_file>\n" "$0"
	exit 1
fi

# Assign variables
source "$1"
input_file="$2"

# Flags to control whether to evaluate over or underexpression
use_min=false
use_max=false

if [ -n "$expression_min" ]; then
	expr_min="$expression_min"
	use_min=true
fi

if [ -n "$expression_max" ]; then
	expr_max="$expression_max"
	use_max=true
fi

# Exit if neither threshold is defined
if ! $use_min && ! $use_max; then
	printf "Error: No expression thresholds provided.\n" >&2
	exit 1
fi

# Read header from TSV
IFS=$'\t' read -r -a header_columns < "$input_file"

# Find condition columns
condition_cols=()
condition_names=()
for i in "${!header_columns[@]}"; do
	if [[ "${header_columns[$i]}" == cond* ]]; then
		condition_cols+=("$i")
		condition_names+=("${header_columns[$i]}")
	fi
done

# Determine prefix based on threshold configuration
if $use_min && $use_max; then
	prefix="in_range_"
	printf "Filtering genes in range: > %s AND < %s\n" "$expr_min" "$expr_max"
elif $use_min; then
	prefix="overexpressed_"
	printf "Filtering genes above the MINIMUM set threshold: %s\n" "$expr_min"
elif $use_max; then
	prefix="underexpressed_"
	printf "Filtering genes under the MAXIMUM set threshold: %s\n" "$expr_max"
else
	prefix="expressed_genes"
fi

# Initialize output files: write header for each condition file (full TSV) and empty gene list file
for cond_name in "${condition_names[@]}"; do
	full_file="${prefix}${cond_name}.tsv"
	genes_file="${prefix}genes_${cond_name}"
	
	printf "%s\n" "$(IFS=$'\t'; printf "%s" "${header_columns[*]}")" > "$full_file"
	> "$genes_file"
done

# Prepare evaluation output file (all genes, 1/0 for each condition)
eval_output="evaluation_all_conditions.tsv"
eval_header="$(IFS=$'\t'; printf "%s" "${header_columns[*]}")"
for cond_name in "${condition_names[@]}"; do
	eval_header+=$'\t'"evaluation_${cond_name}"
done
printf "%s\n" "$eval_header" > "$eval_output"

# Process file (skip header)
{
	read -r _  # skip header
	while IFS=$'\t' read -r -a columns; do
		eval_flags=()
		for idx in "${!condition_cols[@]}"; do
			col_index="${condition_cols[$idx]}"
			condition_value="${columns[$col_index]}"
			cond_name="${condition_names[$idx]}"
			
			full_file="${prefix}${cond_name}.tsv"
			genes_file="${prefix}genes_${cond_name}"

			if [[ "$condition_value" =~ ^-?[0-9]+(\.[0-9]+)?$ ]]; then
				is_valid=true
				$use_min && (( $(echo "$condition_value <= $expr_min" | bc -l) )) && is_valid=false
				$use_max && (( $(echo "$condition_value >= $expr_max" | bc -l) )) && is_valid=false
				
				if $is_valid; then
					# Append full row
					printf "%s\n" "$(IFS=$'\t'; printf "%s" "${columns[*]}")" >> "$full_file"
					# Append gene only
					printf "%s\n" "${columns[0]}" >> "$genes_file"
					eval_flags+=(1)
				else
					eval_flags+=(0)
				fi
			else
				eval_flags+=(0)
			fi
		done
		# Write to evaluation file: original columns + flags
		printf "%s\t%s\n" "$(IFS=$'\t'; printf "%s" "${columns[*]}")" "$(IFS=$'\t'; printf "%s" "${eval_flags[*]}")" >> "$eval_output"
	done
} < <(tail -n +2 "$input_file")

# Optionally sort unique gene lists
for cond_name in "${condition_names[@]}"; do
	genes_file="${prefix}genes_${cond_name}"
	if [ -f "$genes_file" ]; then
		sort -u -o "$genes_file" "$genes_file"
	fi
done
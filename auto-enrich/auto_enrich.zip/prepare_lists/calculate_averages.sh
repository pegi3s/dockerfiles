#!/bin/bash

# Check for config file
if [ $# -ne 1 ]; then
	printf "Usage: %s <config>\n" "$0"
	exit 1
fi

# Load configuration
source "$1"
output_file="output_averages"

# Verify input file exists
if [ ! -f "/data/$input" ]; then
	printf "Error: Input file not found.\n"
	exit 1
fi

# Convert gene column (1-based to 0-based)
gene_col=$((gene - 1))

# Prepare arrays
declare -A avg_instructions
avg_keys=()

# Parse avgX keys
for var in $(compgen -v | grep -E '^avg[0-9]+$'); do
	avg_keys+=("$var")
	avg_instructions[$var]="${!var}"
done

# Prepare header
header="gene"
for key in "${avg_keys[@]}"; do
	header+=$'\t'"$key"
done
printf "%s\n" "$header" > "$output_file"

printf "Processing averages...\n"

# Process input TSV file
tail -n +2 "/data/$input" | while IFS=$'\t' read -r -a columns; do

	# Extract gene name
	if [[ $gene_col -ge 0 && $gene_col -lt ${#columns[@]} ]]; then
		gene="${columns[$gene_col]}"
	else
		printf "Warning: Invalid gene column index\n" >&2
		continue
	fi

	output="$gene"

	# Loop through each avgX entry
	for key in "${avg_keys[@]}"; do
		value="${avg_instructions[$key]}"

		# If it contains commas, treat as list of columns to average
		if [[ "$value" == *,* ]]; then
			IFS=',' read -r -a col_indices <<< "$value"
			sum=0
			count=0

			for idx in "${col_indices[@]}"; do
				col_idx=$((idx - 1))
				if [[ $col_idx -ge 0 && $col_idx -lt ${#columns[@]} ]]; then
					val="${columns[$col_idx]}"
					if [[ "$val" =~ ^-?[0-9]+(\.[0-9]+)?$ ]]; then
						sum=$(echo "$sum + $val" | bc -l)
						((count++))
					fi
				fi
			done

			avg_val=$([[ $count -gt 0 ]] && echo "scale=5; $sum / $count" | bc -l || echo "0")
		else
			# Use single column index as precomputed average
			col_idx=$((value - 1))
			if [[ $col_idx -ge 0 && $col_idx -lt ${#columns[@]} ]]; then
				avg_val="${columns[$col_idx]}"
			else
				avg_val="N/A"
			fi
		fi

		output+=$'\t'"$avg_val"
	done

	# Write to output
	printf "%s\n" "$output" >> "$output_file"
done

# Normalize line endings
sed -i 's/\r//' "$output_file"
#!/bin/bash

# Check if config file and input file are provided
if [ $# -ne 1 ]; then
	printf "Usage: %s <config>\n" "$0"
	exit 1
fi

# Load configuration
source "$1"
output="filtered_isoforms_${input}"

# Verify input file exists
if [ ! -f "/data/$input" ]; then
	printf "Error: Input file not found.\n"
	exit 1
fi

# Only proceed if 'control' variable is defined and not empty
if [ -n "${control:-}" ]; then
	# Check if gene and control are numeric
	if ! [[ "$gene" =~ ^[0-9]+$ ]] || ! [[ "$control" =~ ^[0-9]+$ ]]; then
		echo "Error: 'gene' and 'control' must be numeric column indices (starting at 1)."
		exit 1
	fi
	
	# Convert to zero-based index for awk
	control_col=$((control - 1))
	gene_col=$((gene - 1))

	# Validate that all values in the control column are integers
	if ! tail -n +2 "/data/$input" | cut -f"$control" | grep -vqE '^[0-9]+$'; then
		echo "Error: Non-integer value(s) found in control column $control."
		exit 1
	fi

	# Handle header, sort by control column (descending), then filter unique by gene
	(head -n 1 "/data/$input" && tail -n +2 "/data/$input" | \
	 sort -t$'\t' -k"$control","$control"nr | \
	 awk -F'\t' -v col="$gene_col" '!seen[$col]++') > "$output"
else
	printf "No 'control' column provided in %s. Skipping isoform filtering.\n" "$1"
	exit 2
fi
#!/bin/bash

# Usage check
if [ $# -ne 2 ]; then
	printf "Usage: %s <config_file> <averages_file>\n" "$0"
	exit 1
fi

# Load config
source "$1"
input_file="$2"
output_file="output_conditions"

# Read condition formulas from config
declare -A conditions
c_keys=()

# Get cond1, cond2, ..., from config
for var in $(compgen -v | grep '^cond[0-9]\+$'); do
	conditions[$var]="${!var}"
	c_keys+=("$var")
done

# Read header
IFS=$'\t' read -r -a header_columns < "$input_file"

# Build new header (original columns + condition names)
new_header="$(IFS=$'\t'; echo "${header_columns[*]}")"
for cond in "${c_keys[@]}"; do
	new_header+=$'\t'"$cond"
done
printf "%s\n" "$new_header" > "$output_file"

printf "Calculating condition values and appending to output...\n"

# Process each line of data
tail -n +2 "$input_file" | while IFS=$'\t' read -r -a columns; do
	# Keep original line content
	new_line="$(IFS=$'\t'; echo "${columns[*]}")"

	# For each condition
	for cond in "${c_keys[@]}"; do
		formula="${conditions[$cond]}"
		eval_expr="$formula"

		# Replace all column names with their respective cleaned values
		for ((i=0; i<${#header_columns[@]}; i++)); do
			col_name="${header_columns[$i]}"
			col_value="${columns[$i]}"
			col_value_clean=$(echo "$col_value" | tr -d '\r' | xargs)

			# Replace only if non-empty value
			if [[ -n "$col_value_clean" ]]; then
				eval_expr=$(echo "$eval_expr" | sed "s/\b${col_name}\b/${col_value_clean}/g")
			else
				eval_expr="INVALID"
				break
			fi
		done

		# Debug (optional): print what will be evaluated
		# echo -e "Gene: ${columns[0]}\tFormula: $formula\tEval: $eval_expr" >&2

		# Evaluate expression
		if [[ "$eval_expr" == "INVALID" ]]; then
			result="N/A"
		else
			result=$(echo "$eval_expr" | bc -l 2>/dev/null)
			# Validate and format result
			if [[ -z "$result" || ! "$result" =~ ^-?([0-9]*\.[0-9]+|[0-9]+)$ ]]; then
				result="N/A"
			else
				result=$(printf "%.4f" "$result")
			fi
		fi

		# Append result to output line
		new_line+=$'\t'"$result"
	done

	# Write final line
	printf "%s\n" "$new_line" >> "$output_file"
done

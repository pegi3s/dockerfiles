#!/bin/bash

# Usage check
if [ $# -ne 1 ]; then
	printf "Usage: %s <config>\n" "$0"
	exit 1
fi

# Load config and input file
source "$1"

# Replace Windows \r\n with Unix \n
sed -i 's/\r$//' "/data/$input"

# Ensure input exists
if [ ! -f "/data/$input" ]; then
	printf "Error: Input file not found.\n"
	exit 1
fi

# Ensure gene column name is set
if [ -z "$gene" ]; then
	printf "Error: 'gene' column not defined in config.\n"
	exit 1
fi

# Read header and resolve gene column name to index
header=$(head -n 1 "/data/$input" | sed $'s/\r//;s/^\xEF\xBB\xBF//')
IFS=$'\t' read -ra cols <<< "$header"

declare -A col_indices
for i in "${!cols[@]}"; do
	col=$(echo "${cols[$i]}" | xargs)  # Trim spaces
	col_indices["$col"]=$((i + 1))     # 1-based index for awk
done

# Trim config gene name too
gene=$(echo "$gene" | xargs)
gene_col="${col_indices[$gene]}"

if [[ -z "$gene_col" ]]; then
	printf "Error: Gene column '%s' not found in header.\n" "$gene"
	printf "Available columns: %s\n" "${!col_indices[@]}"
	exit 1
fi

# Skip if control not set
if [ -z "$control" ]; then
	printf "No 'control' column(s) provided. Skipping isoform filtering.\n"
	exit 2
fi

# Parse control columns
IFS=',' read -ra control_cols <<< "$control"
temp_file="tmp_avg.tsv"

# If multiple columns, calculate average into a temp file
if [ "${#control_cols[@]}" -gt 1 ]; then
	printf "Calculating average from columns: %s\n" "${control_cols[*]}"

	# Prepare header
	head -n 1 "/data/$input" | awk -v OFS='\t' '{ print $0, "control_avg" }' > "$temp_file"

	# Calculate row-wise average
	tail -n +2 "/data/$input" | awk -F'\t' -v OFS='\t' -v cols="${control}" '
	BEGIN {
		split(cols, idxs, ",");
		for (i in idxs) {
			idxs[i] = idxs[i] + 0;  # ensure numeric
		}
	}
	{
		sum = 0; count = 0;
		for (i in idxs) {
			val = $(idxs[i]);
			if (val ~ /^[0-9.]+$/) {
				sum += val;
				count++;
			}
		}
		avg = (count > 0) ? sum / count : 0;
		out = $1;
		for (i = 2; i <= NF; i++) out = out OFS $i;
		print out, avg;
	}' >> "$temp_file"

	control_col=$(($(head -n 1 "$temp_file" | awk -F'\t' '{print NF}')))  # last column index
else
	# Just use original file and control as-is
	cp "/data/$input" "$temp_file"
	control_col="${control_cols[0]}"
fi

# Final filtering by selecting the highest expression per gene
output_file="filtered_isoforms_gsea_${input%.tsv}.tsv"
(head -n 1 "$temp_file" && tail -n +2 "$temp_file" | \
 sort -t$'\t' -k${control_col},${control_col}nr | \
 awk -F'\t' -v col="$gene_col" '!seen[$col]++') > "$output_file"

rm "$temp_file"

printf "Isoform filtering completed based on control group samples average. Saved as: %s\n" "$output_file"

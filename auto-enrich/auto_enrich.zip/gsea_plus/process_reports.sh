#!/bin/bash

# Verify number of arguments
if [ $# -ne 1 ]; then
	printf "Usage: %s <results_dir>\n" "$0"
	exit 1
fi

input_dir="$1"

# Check if input directory is valid
if [[ ! -d "$input_dir" ]]; then
	printf "\nError: '%s' is not a valid directory.\n" "$input_dir"
	exit 1
fi

# Get the first-level analysis directory (GSEA result subdir)
analysis_dir=$(find "${input_dir}" -mindepth 1 -maxdepth 1 -type d)
echo "Analysis directory: $analysis_dir"

# Initialize results file
long_results="${analysis_dir}/long_results.csv"
short_results="${analysis_dir}/short_results.csv"

# Write headers
printf "Name,Size,ES,NES,NOM_p-val,FDR_q-val,FWER_p-val,RANK-AT-MAX,Leading_Edge,Source_Report\n" > "$long_results"
printf "Name,NES,FDR_q-val,Source_Report\n" > "$short_results"

# Process all GSEA report files in the directory
report_files=$(find "$analysis_dir" -maxdepth 1 -type f -name "gsea_report_for_*.tsv")

for report_file in $report_files; do
	# Extract group name (last part before ID)
	report_filename=$(basename "$report_file")
	# This regex grabs the last word before the numeric suffix
	group=$(echo "$report_filename" | sed -E 's/^gsea_report_for_(.*)_([0-9]+)\.tsv$/\1/' | awk -F'_' '{print $NF}')

	echo "Processing report: $report_filename (group: $group)"

	tail -n +2 "$report_file" | awk -v group="$group" -F '\t' '
		BEGIN { OFS="," }
		$8 < 0.05 {
			for (i = 1; i <= NF; i++) gsub(",", " ", $i);  # replace commas in fields
			print $1, $4, $5, $6, $7, $8, $9, $10, $11, group
		}
	' >> "$long_results"
done

# Create short results CSV
awk -F',' 'NR==1 {print $1","$4","$6","$10; next} {print $1","$4","$6","$10}' "$long_results" > "$short_results"
#!/bin/bash

# Validate number of arguments
if [ $# -ne 1 ]; then
	printf "Usage: %s <results_dir>\n" "$0"
	exit 1
fi

input_dir="$1"

# Validate input directory
if [[ ! -d "$input_dir" ]]; then
	printf "\nError: '%s' is not a valid directory.\n" "$input_dir"
	exit 1
fi

# Identify analysis subdirectory
analysis_dir=$(find "$input_dir" -mindepth 1 -maxdepth 1 -type d | head -n 1)

if [[ ! -d "$analysis_dir" ]]; then
	printf "\nError: Could not find GSEA results directory inside %s.\n" "$input_dir"
	exit 1
fi

# Create raw_GSEA_output directory and move everything into it
raw_output="${analysis_dir}/raw_GSEA_output"
mkdir -p "$raw_output"
find "$analysis_dir" -mindepth 1 -maxdepth 1 ! -name "raw_GSEA_output" -exec mv {} "$raw_output/" \;

printf "Moved all original GSEA output to: %s\n" "$raw_output"

# Copy all gsea_report_*.tsv files back to the top-level analysis directory
report_files=$(find "$raw_output" -type f -name "gsea_report_*.tsv")
for file in $report_files; do
	cp "$file" "$analysis_dir/"
	echo "Copied $(basename "$file") to $analysis_dir"
done

#!/bin/bash

# Verify number of arguments
if [ $# -ne 2 ]; then
	printf "Usage: %s <results_dir> <gmx_file>\n" "$0"
	exit 1
fi

# Get directory from argument
input_dir="$1"
gmx_file="$2"

# Check if it's a directory
if [[ ! -d "$input_dir" ]]; then
	printf "Error: '$input_dir' is not a valid directory."
	exit 1
fi

# Validate gene set file
if [[ ! -f "$gmx_file" ]]; then
	printf "\nError: Gene Set file '%s' does not exist.\n" "$gmx_file"
	exit 1
fi

# Define paths
analysis_dir=$(find "${input_dir}" -mindepth 1 -maxdepth 1 -type d)
results_file="${analysis_dir}/short_results.csv"
genes_list="${analysis_dir}/raw_GSEA_output/edb/gene_sets.gmt"
terms_dir="${analysis_dir}/terms_annotations"
output_csv="${analysis_dir}/terms_annotations_results.csv"
printf "Name,Source,Ratio(%%),ListCount,Genes_in_list,TermCount,Genes_in_term\n" > "$output_csv"

# Read results file line-by-line (skip header)
tail -n +2 "$results_file" | while IFS=',' read -r name nes fdr source; do
	term_dir="${terms_dir}/${name}"
	mkdir -p "$term_dir"

	# Match gmx_files.gmt
	line_list=$(grep -P "^${name}\t" "$genes_list")
	if [[ -n "$line_list" ]]; then
		genes=$(printf "%s\n" "$line_list" | cut -f3-)
		printf "%s\n" "$genes" | tr '\t' '\n' > "${term_dir}/genes_in_list"
		printf "Written genes_in_list for term: %s\n" "$name"
	fi

	# Match provided gmx_file file
	line_term=$(grep -P "^${name}\t" "$gmx_file")
	if [[ -n "$line_term" ]]; then
		genes=$(printf "%s\n" "$line_term" | cut -f3-)
		printf "%s\n" "$genes" | tr '\t' '\n' > "${term_dir}/genes_in_term"
		printf "Written genes_in_term file for term: %s\n" "$name"
	fi

	# Prepare compiled CSV entry
	genes_in_list=$(< "${term_dir}/genes_in_list")
	genes_in_term=$(< "${term_dir}/genes_in_term")

	count_list=$(printf "%s\n" "$genes_in_list" | wc -l)
	count_term=$(printf "%s\n" "$genes_in_term" | wc -l)
	
	ratio=0
	if [[ $count_term -ne 0 ]]; then
		ratio=$(awk "BEGIN { printf \"%.4f\", ($count_list / $count_term)*100 }")
	fi

	genes_list_str=$(printf "%s" "$genes_in_list" | paste -sd "'" -)
	genes_term_str=$(printf "%s" "$genes_in_term" | paste -sd " " -)

	printf "%s,%s,%s,%s,\"%s\",%s,\"%s\"\n" "$name" "$source" "$ratio" "$count_list" "$genes_list_str" "$count_term" "$genes_term_str" >> "$output_csv"

done
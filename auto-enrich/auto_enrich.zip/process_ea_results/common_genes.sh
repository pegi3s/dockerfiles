#!/bin/bash

if [ $# -ne 2 ]; then
	printf "Usage: %s <results_directory> <max_n_occurences>\n" "$0"
	exit 1
fi

# Get directory from argument
input_dir="$1"
cutoff="$2"

# Check if it's a directory
if [[ ! -d "$input_dir" ]]; then
	printf "\nError: %s is not a valid directory.\n" "$input_dir"
	exit 1
fi

terms_results_file="${input_dir}/terms_annotations_results.csv"

# Check if the file exists
if [[ ! -f "$terms_results_file" ]]; then
	printf "\nError: '%s' does not exist.\n" "$terms_results_file"
	exit 1
fi

# Get the column number for "GeneIDs_in_list" first, fallback to "Genes_in_list"
genes_col=$(head -n 1 "$terms_results_file" | tr ',' '\n' | nl -v 1 | awk '$2 == "GeneIDs_in_list" { print $1 }')

if [[ -z "$genes_col" ]]; then
	genes_col=$(head -n 1 "$terms_results_file" | tr ',' '\n' | nl -v 1 | awk '$2 == "Genes_in_list" { print $1 }')

	if [[ -z "$genes_col" ]]; then
		printf "\nError: Neither 'GeneIDs_in_list' nor 'Genes_in_list' columns were found in the header of %s.\n" "$terms_results_file"
		exit 1
	else
		printf "Info: Using column 'Genes_in_list' for gene filtering.\n"
	fi
else
	printf "Info: Using column 'GeneIDs_in_list' for gene filtering.\n"
fi
if [[ -z "$genes_col" ]]; then
	printf "\nError: Column 'Genes_in_list' not found in header of %s.\n" "$terms_annotations_results"
	exit 1
fi

# Output file
output_file="${input_dir}/excluded_genes"
printf "N_Occurences\tGeneID\n" > "$output_file"

# Process the file using the dynamically found column
tail -n +2 "$terms_results_file" | \
	awk -F',' -v col="$genes_col" '{print $col}' | \
	tr ' ' '\n' | \
	sed "s/'//g" | \
	sed '/^$/d' | \
	sort | \
	uniq -c | \
	awk -v cutoff="$cutoff" '$1 > cutoff { print $1 "\t" $2 }' >> "$output_file"

printf "Genes with > %s occurrences saved to: %s\n" "$cutoff" "$output_file"
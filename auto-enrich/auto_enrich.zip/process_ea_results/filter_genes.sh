#!/bin/bash

# Check input
if [ $# -ne 1 ]; then
	printf "Usage: %s <results_directory>\n" "$0"
	exit 1
fi

input_dir="$1"
input_file="${input_dir}/terms_annotations_results.csv"
common_genes_file="${input_dir}/excluded_genes"
output_file="filtered_genes"

# Check for input files
if [[ ! -f "$input_file" ]]; then
	printf "Error: File '%s' not found." "$input_file"
	exit 1
fi

if [[ ! -f "$common_genes_file" ]]; then
	printf "Error: File '%s' not found." "$common_genes_file"
	exit 1
fi

# Load common genes into an associative array (for fast lookups)
declare -A common_genes
while read -r count gene; do
	common_genes["$gene"]=1
done < "$common_genes_file"

# Determine column indexes
header_line=$(head -n 1 "$input_file")
IFS=',' read -ra headers <<< "$header_line"

geneids_col=-1
genesym_col=-1

for i in "${!headers[@]}"; do
	if [[ "${headers[$i]}" == "GeneIDs_in_list" ]]; then
		geneids_col=$i
	elif [[ "${headers[$i]}" == "Genes_in_list" ]]; then
		genesym_col=$i
	fi
done

if [[ $genesym_col -eq -1 ]]; then
	printf "Error: Column 'Genes_in_list' not found.\n"
	exit 1
fi

# Process file
{
	echo "$header_line"  # print header

	tail -n +2 "$input_file" | while IFS= read -r line; do
		IFS=',' read -ra cols <<< "$line"

		gene_syms="${cols[$genesym_col]}"
		IFS=' ' read -ra syms_arr <<< "$gene_syms"

		if [[ $geneids_col -ge 0 ]]; then
			gene_ids="${cols[$geneids_col]}"
			IFS=' ' read -ra ids_arr <<< "$gene_ids"

			# Ensure parallel arrays
			if [[ ${#ids_arr[@]} -ne ${#syms_arr[@]} ]]; then
				continue
			fi

			filtered_ids=()
			filtered_syms=()

			for i in "${!ids_arr[@]}"; do
				clean_id="${ids_arr[$i]//\'/}"
				if [[ -z "${common_genes[$clean_id]}" ]]; then
					filtered_ids+=("'$clean_id'")
					filtered_syms+=("${syms_arr[$i]}")
				fi
			done

			if [[ ${#filtered_ids[@]} -eq 0 ]]; then
				continue
			fi

			cols[$((geneids_col))]="${filtered_ids[*]}"
			cols[$((genesym_col))]="${filtered_syms[*]}"

		else
			# Only symbols present
			filtered_syms=()
			for sym in "${syms_arr[@]}"; do
				clean_sym="${sym//\'/}"
				if [[ -z "${common_genes[$clean_sym]}" ]]; then
					filtered_syms+=("$sym")
				fi
			done
			if [[ ${#filtered_syms[@]} -eq 0 ]]; then
				continue
			fi
			cols[$((genesym_col))]="${filtered_syms[*]}"
		fi

		# Optionally update number of genes if that column exists (e.g., col[4]?)
		output="${cols[0]}"
		for ((i=1; i<${#cols[@]}; i++)); do
			output+=",""${cols[$i]}"
		done
		echo "$output"
	done
} > "$output_file"

printf "Filtered genes saved to: %s\n" "$output_file"
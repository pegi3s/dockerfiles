# Developing CPORT

This section is still work in progress

## Testing

```text
pip install pytest
pytest
```

## Linting

If you are using VSCode, then [this extension](https://marketplace.visualstudio.com/items?itemName=Trunk.io) make it easy to check for style errors.

If you are using other code editor, then install [trunk](https://trunk.io/products/check) locally and check the formatting of the code with `trunk check` and simply apply the changes with `trunk fmt`.

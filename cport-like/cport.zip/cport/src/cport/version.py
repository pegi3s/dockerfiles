"""Version information."""
VERSION = "0.1.0-unreleased"
v_major, v_minor, v_patch = VERSION.split(".")
